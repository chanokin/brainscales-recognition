# Client software for the Human Brain Project Neuromorphic Computing Platform


For documentation, see https://electronicvisions.github.io/hbp-sp9-guidebook/

For more information about the Human Brain Project, see https://www.humanbrainproject.eu/


[![Build Status](https://travis-ci.org/HumanBrainProject/hbp-neuromorphic-client.svg?branch=master)](https://travis-ci.org/HumanBrainProject/hbp-neuromorphic-client)
